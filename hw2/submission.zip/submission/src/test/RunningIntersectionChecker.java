package test;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

import bp.Clique;
import bp.Main;

public class RunningIntersectionChecker 
{
	public static void main(String[] args) throws FileNotFoundException 
	{
		HashMap<List<String>, Clique> cliques = Main.readInCliques(args[0]);
		HashMap<Integer, Clique> cliqueIds = new HashMap<Integer, Clique>();
	
		for (List<String> variables : cliques.keySet())
		{
			Clique clique = cliques.get(variables);
			cliqueIds.put(clique.getId(), clique);
		}
		
		System.out.println("There are " + Main.rvToCliques.keySet().size() + " variables");
		
		for (String variable : Main.rvToCliques.keySet())
		{
			List<Integer> ids = Main.rvToCliques.get(variable);
			
			for (Integer i : ids)
			{
				Clique start = cliqueIds.get(i);
				for (Integer j : ids)
				{
					Clique end = cliqueIds.get(j);
					
					if (!existsPath(start, end, variable, ids))
					{
						System.out.println("shit");
						System.out.println(start.getId());
						System.out.println(end.getId());
						System.out.println(variable);
						System.out.println();
						System.exit(0);
					}
				}
				
			}
		}
		System.out.println("It's good!");
	}
	
	public static boolean existsPath(Clique start, Clique end, String variable, List<Integer> ids)
	{
		if (start.getId() == end.getId())
			return true;
		
		Queue<Clique> queue = new LinkedList<Clique>();
		Set<Clique> used = new HashSet<Clique>();
		
		// add start's neighbors to queue
		for (Clique neighbor : start.getNeighbors())
		{
			if (neighbor.getId() == end.getId() && end.getVariables().contains(variable))
				return true;
			
			if (!queue.contains(neighbor) && neighbor.getVariables().contains(variable))
				queue.add(neighbor);
		}
		
		while (!queue.isEmpty())
		{
			Clique clique = queue.remove();
			used.add(clique);
			
			if (!clique.getVariables().contains(variable))
				continue;
			
			if (clique.getId() == end.getId())
				return true;
			else
			{
				for (Clique neighbor : clique.getNeighbors())
				{
					if (!queue.contains(neighbor) && neighbor.getVariables().contains(variable) && !used.contains(neighbor))
						queue.add(neighbor);
				}
			}
		}
		
		
		return false;
	}
}
